const fs = require('fs');
const FILE = 'todos.json';
const load = () => (fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE)) : []);
const save = (t) => fs.writeFileSync(FILE, JSON.stringify(t, null, 2));

const [, , cmd, ...rest] = process.argv;
const todos = load();
const text = rest.join(' ');
const i = Number(rest[0]) - 1;

if (cmd === 'add' && text) {
  todos.push({ text, done: false });
  save(todos);
  console.log('Added:', text);
} else if (cmd === 'done' && todos[i]) {
  todos[i].done = true;
  save(todos);
  console.log('Done!');
} else if (cmd === 'remove' && todos[i]) {
  todos.splice(i, 1);
  save(todos);
  console.log('Removed');
} else if (cmd === 'list') {
  if (!todos.length) console.log('Nothing yet. Try: node todo.js add Learn C++');
  todos.forEach((t, n) => console.log(`${n + 1}. [${t.done ? 'x' : ' '}] ${t.text}`));
} else {
  console.log('Usage: node todo.js add <task> | list | done <number> | remove <number>');
}
