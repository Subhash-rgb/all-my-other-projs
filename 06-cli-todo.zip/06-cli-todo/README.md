# CLI To-Do

A to-do list you control from the terminal. Tasks are saved in a `todos.json` file. Node.js, no packages needed.

## How to run

```
node todo.js add Learn C++
node todo.js list
node todo.js done 1
node todo.js remove 1
```

Made by Subhash.
