# Pixel Art Board

A 16x16 drawing board. Pick a colour, paint with your mouse or finger, and save your art as a PNG.

## How to run

Open `index.html` in a browser.

Made by Subhash.
