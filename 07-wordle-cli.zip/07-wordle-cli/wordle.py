import random

WORDS = ["array", "logic", "pixel", "token", "cache", "debug", "stack", "queue",
         "loops", "class", "input", "build", "merge", "shell", "parse"]
GREEN, YELLOW, GREY, END = "\033[92m", "\033[93m", "\033[90m", "\033[0m"


def score(guess, answer):
    out = [GREY + c + END for c in guess]
    left = list(answer)
    for i, c in enumerate(guess):
        if c == answer[i]:
            out[i] = GREEN + c + END
            left[i] = None
    for i, c in enumerate(guess):
        if c != answer[i] and c in left:
            out[i] = YELLOW + c + END
            left[left.index(c)] = None
    return "".join(out)


answer = random.choice(WORDS)
print("Guess the 5-letter coding word. You have 6 tries.")
for turn in range(1, 7):
    guess = ""
    while len(guess) != 5 or not guess.isalpha():
        guess = input(f"Guess {turn}: ").strip().lower()
    print(score(guess, answer))
    if guess == answer:
        print("You got it!")
        break
else:
    print("The word was", answer)
