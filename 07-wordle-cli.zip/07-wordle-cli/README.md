# Wordle CLI

A Wordle-style game in the terminal with coding words. Green means right spot, yellow means wrong spot. Python, no packages needed.

## How to run

Run `python3 wordle.py`.

Made by Subhash.
