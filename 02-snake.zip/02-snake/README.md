# Snake

The classic Snake game on a canvas. Eat the red squares, don’t hit the walls or yourself.

## How to run

Open `index.html` in a browser and use the arrow keys.

Made by Subhash.
