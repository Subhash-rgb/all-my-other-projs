# Sudoku Solver

Solves any valid Sudoku using backtracking. Written in C++.

## How to run

```
g++ -O2 -o sudoku sudoku.cpp
./sudoku < puzzle.txt
```
Puzzle format: 9 rows of 9 digits, with 0 for blanks.

Made by Subhash.
