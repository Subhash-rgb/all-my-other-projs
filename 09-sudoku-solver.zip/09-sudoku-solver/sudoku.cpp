#include <iostream>
#include <string>
using namespace std;

int g[9][9];

bool ok(int r, int c, int v) {
    for (int i = 0; i < 9; i++)
        if (g[r][i] == v || g[i][c] == v) return false;
    int br = r / 3 * 3, bc = c / 3 * 3;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (g[br + i][bc + j] == v) return false;
    return true;
}

bool solve(int p) {
    if (p == 81) return true;
    int r = p / 9, c = p % 9;
    if (g[r][c]) return solve(p + 1);
    for (int v = 1; v <= 9; v++) {
        if (ok(r, c, v)) {
            g[r][c] = v;
            if (solve(p + 1)) return true;
            g[r][c] = 0;
        }
    }
    return false;
}

int main() {
    cout << "Enter 9 rows of 9 digits (0 for blank):\n";
    for (int i = 0; i < 9; i++) {
        string s;
        cin >> s;
        if (s.size() != 9) { cout << "Each row needs exactly 9 digits\n"; return 1; }
        for (int j = 0; j < 9; j++) g[i][j] = s[j] - '0';
    }
    if (!solve(0)) { cout << "No solution\n"; return 0; }
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) cout << g[i][j] << (j % 3 == 2 && j < 8 ? " | " : " ");
        cout << "\n";
        if (i % 3 == 2 && i < 8) cout << "------+-------+------\n";
    }
}
