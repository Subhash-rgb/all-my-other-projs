#include <iostream>
#include <algorithm>
using namespace std;

char b[9];

int win() {
    int w[8][3] = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
    for (auto &l : w)
        if (b[l[0]] != ' ' && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]])
            return b[l[0]] == 'O' ? 1 : -1;
    return 0;
}

bool full() {
    for (char c : b) if (c == ' ') return false;
    return true;
}

int minimax(bool ai) {
    int s = win();
    if (s || full()) return s;
    int best = ai ? -2 : 2;
    for (int i = 0; i < 9; i++) {
        if (b[i] == ' ') {
            b[i] = ai ? 'O' : 'X';
            int v = minimax(!ai);
            b[i] = ' ';
            best = ai ? max(best, v) : min(best, v);
        }
    }
    return best;
}

void show() {
    for (int i = 0; i < 9; i += 3)
        cout << " " << b[i] << " | " << b[i+1] << " | " << b[i+2] << "\n" << (i < 6 ? "---+---+---\n" : "");
}

int main() {
    fill(b, b + 9, ' ');
    cout << "You are X. Pick squares 1-9.\n";
    while (true) {
        show();
        int m;
        cout << "Your move: ";
        if (!(cin >> m)) return 0;
        m--;
        if (m < 0 || m > 8 || b[m] != ' ') { cout << "Invalid\n"; continue; }
        b[m] = 'X';
        if (win() || full()) break;
        int bm = -1, bv = -2;
        for (int i = 0; i < 9; i++) {
            if (b[i] == ' ') {
                b[i] = 'O';
                int v = minimax(false);
                b[i] = ' ';
                if (v > bv) { bv = v; bm = i; }
            }
        }
        b[bm] = 'O';
        if (win() || full()) break;
    }
    show();
    int w = win();
    cout << (w == 1 ? "I win!" : w == -1 ? "You win!" : "Draw!") << "\n";
}
