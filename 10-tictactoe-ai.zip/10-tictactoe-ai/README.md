# Tic-Tac-Toe AI

Play Tic-Tac-Toe against an AI that uses minimax, so it never loses. Can you get a draw? Written in C++.

## How to run

```
g++ -O2 -o tictactoe tictactoe.cpp
./tictactoe
```

Made by Subhash.
