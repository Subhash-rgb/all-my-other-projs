# Focus Timer

A Pomodoro study timer: 25 minutes of focus, 5 minutes of break, with a session counter. The time also shows in the browser tab.

## How to run

Open `index.html` in a browser.

Made by Subhash.
