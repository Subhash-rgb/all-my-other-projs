# Knight’s Tour

Click any square and watch a knight visit all 64 squares exactly once, using Warnsdorff’s rule. Pure HTML, CSS and JavaScript.

## How to run

Open `index.html` in a browser.

Made by Subhash.
