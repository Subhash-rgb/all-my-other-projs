# URL Shortener

A tiny link shortener server using only Node.js built-ins. Paste a link, get a short one. Links live in memory, so they reset when the server restarts.

## How to run

Run `node server.js`, then open http://localhost:3000.

Made by Subhash.
