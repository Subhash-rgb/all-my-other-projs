const http = require('http');
const links = new Map();
const id = () => Math.random().toString(36).slice(2, 8);
const page = `<h1>Short links</h1><form method=post action=/new><input name=url placeholder="https://..." size=40><button>Shorten</button></form>`;

http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/new') {
    let body = '';
    req.on('data', d => body += d);
    req.on('end', () => {
      const url = new URLSearchParams(body).get('url') || '';
      if (!/^https?:\/\//.test(url)) {
        res.writeHead(400);
        return res.end('Enter a link starting with http:// or https://');
      }
      const k = id();
      links.set(k, url);
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(`<p>Your link: <a href="/${k}">http://localhost:3000/${k}</a></p><a href="/">Make another</a>`);
    });
    return;
  }
  const k = req.url.slice(1);
  if (links.has(k)) {
    res.writeHead(302, { Location: links.get(k) });
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(page);
}).listen(3000, () => console.log('Running on http://localhost:3000'));
