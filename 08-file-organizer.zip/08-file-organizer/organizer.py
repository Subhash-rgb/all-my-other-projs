import shutil
import sys
from pathlib import Path

TYPES = {
    "Images": [".jpg", ".jpeg", ".png", ".gif", ".webp"],
    "Documents": [".pdf", ".docx", ".txt", ".pptx", ".xlsx"],
    "Code": [".py", ".js", ".html", ".css", ".cpp"],
    "Archives": [".zip", ".rar", ".7z"],
    "Video": [".mp4", ".mkv", ".mov"],
    "Audio": [".mp3", ".wav"],
}


def folder_for(ext):
    for name, exts in TYPES.items():
        if ext in exts:
            return name
    return "Other"


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    root = Path(args[0]).expanduser() if args else Path.cwd()
    dry = "--apply" not in sys.argv
    for f in root.iterdir():
        if f.is_file() and not f.name.startswith(".") and f.name != Path(__file__).name:
            dest = root / folder_for(f.suffix.lower())
            print("Would move" if dry else "Moving", f.name, "->", dest.name)
            if not dry:
                dest.mkdir(exist_ok=True)
                shutil.move(str(f), str(dest / f.name))
    if dry:
        print("\nThis was a preview. Add --apply to really move files.")


main()
