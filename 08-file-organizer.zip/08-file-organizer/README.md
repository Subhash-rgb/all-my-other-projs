# File Organizer

Sorts the files in a folder into Images, Documents, Code, Archives, Video, Audio and Other. It shows a preview first and only moves files when you add `--apply`.

## How to run

```
python3 organizer.py ~/Downloads          # preview only
python3 organizer.py ~/Downloads --apply  # really move files
```

Made by Subhash.
